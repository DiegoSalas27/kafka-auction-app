REALTIME_ANALYTICS = 'realtime-analytics'
TIMER = 'timer'
HIGHEST_BIDDERS = 'highest-bidders'